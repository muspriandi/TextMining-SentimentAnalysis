# InSet (Indonesia Sentiment Lexicon)

This is a sentiment lexicon for Indonesia Language and it's construction refers to:

Fajri Koto, and Gemala Y. Rahmaningtyas "InSet Lexicon: Evaluation of a Word List for Indonesian 
Sentiment Analysis in Microblogs". IEEE in the 21st International Conference on Asian Language Processing 
(IALP), Singapore, December 2017.

The InSet Lexicon consists of 3,609 positive words and 6,609 negative words with weight ranging from -5 to +5

Paper: https://www.researchgate.net/publication/321757985_InSet_Lexicon_Evaluation_of_a_Word_List_for_Indonesian_Sentiment_Analysis_in_Microblogs
