.. _feature_selection_examples:

Feature Selection
-----------------------

Examples concerning the :mod:`sklearn.feature_selection` module.
