import xlrd
import openpyxl

fileopen=xlrd.open_workbook('tweet1clean.xlsx')
dataTrain = fileTrain.sheet_by_index(0)

print book.nsheets
